export const environment = {
  production: true,

  api_url: '',
  api_img_url: '',
  session_time_limit: 20,
};

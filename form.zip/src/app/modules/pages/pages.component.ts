import { Component } from '@angular/core';

@Component({
  selector: 'ngx-pages',
  styleUrls: ['pages.component.scss'],
  templateUrl: './pages.component.html'
})
export class PagesComponent {
  
  menu = [
    {
      title: 'Module 1',
      icon: 'fas fa-chart-line icon',
      link: '/pages/module1'
    },
    {
      title: 'Module 2',
      icon: 'fas fa-desktop icon',
      link: '/pages/module2',
    
    }
  ];

  

  constructor(){}

  ngOnInit(): void {
  
  }
}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Module1Component } from './module1.component';
import { Module1RoutingModule } from './module1-routing.module';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [Module1Component],
  imports: [
    CommonModule,
    RouterModule,
    Module1RoutingModule
  ]
})
export class Module1Module { }

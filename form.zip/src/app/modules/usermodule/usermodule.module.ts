import { NgModule, NO_ERRORS_SCHEMA,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { UsermoduleRoutingModule } from './usermodule-routing.module';
import { CoreModule } from 'src/app/core/core.module';
import { UserPictureComponent } from './user-profile/user-picture/user-picture.component';
import { ProfileFormComponent } from './user-profile/profile-form/profile-form.component';
import { MiscellaneousComponent } from './user-profile/miscellaneous/miscellaneous.component';



@NgModule({
  declarations: [UserProfileComponent, UserPictureComponent, ProfileFormComponent, MiscellaneousComponent],
  imports: [
    CommonModule,
    UsermoduleRoutingModule,
    SharedModule,
    CoreModule,
    FormsModule,
    
    
  ],
  exports: [
    UserProfileComponent
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class UsermoduleModule { }

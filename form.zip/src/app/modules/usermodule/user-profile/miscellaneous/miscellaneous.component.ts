import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-miscellaneous',
  templateUrl: './miscellaneous.component.html',
  styleUrls: ['./miscellaneous.component.scss']
})
export class MiscellaneousComponent implements OnInit {

  permissionCardDetails: any[] = [
    {
      type: "Import Records",
      status: true,
      access: "create, read , write , delete , Leads, Contacts, Tasks",
    },
    {
      type: "Manage and Custom View",
      status: false,
      access: "Leads, Contacts, Tasks",
    },
    {
      type: "Payroll Users",
      status: true,
      access: "create , write , delete , create , write , Leads, Contacts, Tasks",
    },
  ];

  constructor() { }

  ngOnInit(): void {
  }

  onChangePremissionData(data) {

    this.permissionCardDetails.forEach( (permissionCard , index) => {
      if(index === data.index) {
        permissionCard.status = data.status;
        permissionCard.access = data.access;
        return false;
      }
    });
    console.log(this.permissionCardDetails);
  }

}

import { Component, OnInit } from '@angular/core';
//import { FormControl } from '@angular/forms';


 

@Component({
  selector: 'app-user-picture',
  templateUrl: './user-picture.component.html',
  styleUrls: ['./user-picture.component.scss']
})
export class UserPictureComponent implements OnInit {

  constructor() { }
  ngOnInit(): void {
  }

 
  onFileChanged(event) {
    const file = event.target.files[0]
  }

  /*
  onUpload() {
    
  } */
  

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {UserProfileComponent} from 'src/app/modules/usermodule/user-profile/user-profile.component'


const routes: Routes = [{
  path: '',
  component: UserProfileComponent,
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})


export class UsermoduleRoutingModule { }

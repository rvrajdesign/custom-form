import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApiService } from './services/api.service';
import { AuthGuardService } from './services/auth-guard.service';
import { HttpInterceptorService } from './services/http-interceptor.service';
import { JwtService } from './services/jwt.service';
import { LocalStorageService } from './services/local-storage.service';
import { UserService } from './services/user.service';
import { LoaderService } from './services/loader.service';



// Services
const SERVICES = [
  ApiService,
  AuthGuardService,
  HttpInterceptorService,
  JwtService,
  LoaderService,
  LocalStorageService,
  UserService
]


@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers: [
    ...SERVICES,
  ]
})
export class CoreModule {

  static forRoot(): ModuleWithProviders<CoreModule> {
    return {
      ngModule: CoreModule,
      providers: [
        ...SERVICES,
      ],
    };
  }
  
}

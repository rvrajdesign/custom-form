import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {

  constructor() { }

  getItem(name) {
    const data = localStorage.getItem(name);
    return (data) ? atob(data) : null;
  }

  setItem(name, item) {
    localStorage.setItem(name, btoa(item));
  }

  removeItem(name) {
    localStorage.removeItem(name);
  }

}

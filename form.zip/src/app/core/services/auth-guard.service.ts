import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

import { UserService } from './user.service'
import { JwtService } from './jwt.service'

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  constructor(
    private jwtService: JwtService,
    private userService: UserService,
    private router: Router
  ) { 
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    if (this.jwtService.getToken() && this.userService.validateSession()) {
      this.setLoggedIn(true)
      return true
    } else {
      this.setLoggedIn(false)
      this.router.navigate(['/auth/login']);
      return false;
    }
  }

  get isLoggedIn() {
    return this.loggedIn.asObservable();
  }

  setLoggedIn(isLogged: boolean) {
    this.loggedIn.next(isLogged);
  }
  
}

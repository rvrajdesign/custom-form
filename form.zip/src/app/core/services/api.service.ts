import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpErrorResponse, HttpEventType, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, retry, delay } from 'rxjs/operators';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(public http: HttpClient) { }

  // get method
  public get(path: string, params: HttpParams = new HttpParams()): Observable<any> {
    return this.http.get(`${environment.api_url}${path}`, { params })
      .pipe(map(response => response), catchError(error => of(error)));
  }

  // put method
  public put(path: string, body: Object = {}): Observable<any> {
    return this.http.put(`${environment.api_url}${path}`, body)
      .pipe(map(response => response), catchError(error => of(error)));
  }

  // post method
  public post(path: string, body: Object = {}): Observable<any> {
    return this.http.post(`${environment.api_url}${path}`, body)
      .pipe(map(response => response), catchError(error => of(error)));
  }

  // delete method
  public delete(path: string, params: HttpParams = new HttpParams()): Observable<any> {
    return this.http.delete(`${environment.api_url}${path}`, { params })
      .pipe(map(response => response), catchError(error => of(error)));
  }


  // file upload post method
  public fileUploadPost(path: string, body: Object = {}): Observable<any> {
    return this.http.post(`${environment.api_img_url}${path}`, body, {
      reportProgress: true,
      observe: 'events'
    })
      .pipe(map((event) => {
        switch (event.type) {

          case HttpEventType.UploadProgress:
            const progress = Math.round(100 * event.loaded / event.total);
            return { status: 'progress', progress: progress };

          case HttpEventType.Response:
            return event.body;
          default:
            return { status: 'default', message: `Unhandled event: ${event.type}`};
        }
      }), catchError(error => of(error)));
  }

}

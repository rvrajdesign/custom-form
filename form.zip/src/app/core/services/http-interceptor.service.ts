import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize } from "rxjs/operators";

// jwt service
import { JwtService } from './jwt.service';

// user service
import { UserService } from './user.service';

// Loader service
import { LoaderService } from './loader.service';


@Injectable({
  providedIn: 'root'
})
export class HttpInterceptorService implements HttpInterceptor  {

  constructor(private jwtService: JwtService, private userService: UserService, public loaderService: LoaderService) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // get token
    const token = this.jwtService.getToken();

    // token present set authorization header and update user session time
    if (token) {
      this.userService.updateSessionTime();
      this.loaderService.show();
      return next.handle(
        req.clone({
          headers: req.headers.append('Authorization', 'Bearer ' + token)
        })
      ).pipe(finalize(() => this.loaderService.hide()));

    }
    return next.handle(req);
  }
}

import { Injectable } from '@angular/core';

import { LocalStorageService } from './local-storage.service';

import { environment } from 'src/environments/environment';

import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private organizationImageUrl = new BehaviorSubject({});
  currentLogo = this.organizationImageUrl.asObservable();

  constructor(
    private localStorage: LocalStorageService
  ) { }


  getSession() {
    let _session = this.localStorage.getItem('Session');
    _session = (_session) ? JSON.parse(_session) : '';
    console.log(_session)

    return _session;
  }

  get canShow() {
    let _session = this.localStorage.getItem('Session');
    _session = (_session) ? JSON.parse(_session) : '';
    return _session['policyList'];
  }


  get infoData() {
    let _session = this.localStorage.getItem('infoData');
    _session = (_session) ? JSON.parse(_session) : '';
    return _session;
  }

  updateInfo(info) {
    this.localStorage.setItem('infoData', JSON.stringify(info))
  }

  updateSession(session) {
    let _session = session
    _session['session_time'] = Date();
    this.localStorage.setItem('Session', JSON.stringify(_session));
  }

  // update user session time 
  updateSessionTime() {
    let _session = this.getSession();

    if (_session) {
        _session['session_time'] = Date();
        this.localStorage.setItem('Session', JSON.stringify(_session));
    }
   
  }



  // destroy Session
  destroySession() {
    this.localStorage.removeItem('Session');
  }

  // validate user session
  validateSession(): boolean {

    // get current and logged/updated session
    const _currentDate = new Date();

    const _session = this.getSession();
    const _sessionDate = new Date(_session['session_time']);

    // calc time difference in hours
    const _sessionDiff = Math.abs(_currentDate.getTime() - _sessionDate.getTime()) / 36e5;

    // validate with session timeout and return result
    const _sessionValid = (_sessionDiff <= environment.session_time_limit) ? true : false;
    return _sessionValid;
  }

}

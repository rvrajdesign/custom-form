import { Injectable } from '@angular/core';

// Services
import { LocalStorageService } from './local-storage.service';

@Injectable({
  providedIn: 'root'
})
export class JwtService {

  constructor(
    private localStorage: LocalStorageService
  ) { }

  // get token by decrypt
  getToken(): string {
    let _token = this.localStorage.getItem('Token');
    return (_token) ? _token : '';
  }

  // save token by encrypt
  saveToken(token: string) {
    this.localStorage.setItem('Token', token)
  }

  // destroy token
  destroyToken() {
    this.localStorage.removeItem('Token');
  }
}

export const DEFAULT = {


}


export interface MENU {
    title: string,
    link?: string,
    url?: string,
    icon?: string,
    children?: MENU[],
    hidden?: boolean,
    pathMatch?: 'full' | 'prefix';
    home?: boolean,
    selected?: boolean,
    data?: string
}
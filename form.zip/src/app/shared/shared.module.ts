import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NgbModule, NgbAlertModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap'

import { LayoutComponent } from './components/layout/layout.component';
import { LoaderComponent } from './components/loader/loader.component';
import { PermissionsComponent } from './components/permissions/permissions.component';
import { ToggleButtonComponent } from './components/toggle-button/toggle-button.component';
import { RouterModule } from '@angular/router';
import { MortgageLibModule } from 'mortgage-lib';
import { CustomInputComponent } from './components/custom-input/custom-input.component';





// COMPONENTS
const COMPONENTS = [
  LayoutComponent,
  LoaderComponent,
  PermissionsComponent,
  ToggleButtonComponent,
  CustomInputComponent
]

// NGB MODULES
const NGB_MODULES = [
  NgbModule,
  NgbAlertModule,
  NgbTooltipModule,
  MortgageLibModule
]

@NgModule({
  declarations: [...COMPONENTS, ],
  imports: [ CommonModule, RouterModule, ...NGB_MODULES ],
  exports: [ CommonModule, ...COMPONENTS, ...NGB_MODULES ]
})

export class SharedModule { 
  static forRoot(): ModuleWithProviders<SharedModule> {
    return {
      ngModule: SharedModule,
    };
  }
}

import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import * as $ from 'jquery';

import { MENU } from 'src/app/core/models/default.model';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

  subscription$: Subscription;

  @Input() menu: MENU[];

  currentMenu: MENU = null;
  currentRoute = '';


  smenu = [
    {
      title: 'Sun Module 1',
      icon: 'fas fa-chart-line icon',
      link: '/pages/sub_module1'
    },
    {
      title: 'Sub Module 2',
      icon: 'fas fa-desktop icon',
      link: '/pages/sub_module2',
    
    }
  ];

  menuStyle = {
    width: '100%',
    primaryColor: '#fff',
    textColor:'#78909C',
    backgroundColor: '#fff',
    // height: '50vh',
    fontSize: '1.2rem',
    primaryHoverColor: '#9FA8DA',
    textHoverColor: '#fff'
  }

  constructor(
    private router: Router,
    private activeRoute: ActivatedRoute
  ) { 
    router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
          console.log(event.urlAfterRedirects, this.menu);

      }
    });
    this.updateSelectedMenu()

   
  }

  ngOnInit() {
    // this.updateSelectedMenu();
  }

  ngOnChanges(changes: SimpleChanges): void {
    //Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    //Add '${implements OnChanges}' to the class.
    if (changes) {

      // Update current active menu on page/window reload
      if (changes['menu'] && changes['menu'].currentValue.length > 0) {
        console.log('menu', this.currentRoute, changes['menu'].currentValue);

        this.currentMenu = changes['menu'].currentValue.find(x =>  x.link == this.currentRoute);
      }
    }
  }

 
  toggleSideNav() {
    // open or close navbar
    $('#sidebar').toggleClass('active');
   
  }

  updateSelectedMenu() {
    // update active menu on navigate
    console.log('updateSelectedMenu')
    this.router.events.pipe(filter( event => event instanceof NavigationEnd)).subscribe(event => {
     console.log('current route: ', event);
     this.currentRoute = event['url'];
      if (this.menu && this.menu.length > 0) {
        this.currentMenu = this.menu.find(x => x.link == event['url']);
      } 
    });
  }



  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    if (this.subscription$) this.subscription$.unsubscribe();
  }
}

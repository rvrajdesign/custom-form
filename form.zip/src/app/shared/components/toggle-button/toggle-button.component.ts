import { Component, OnInit, Input , Output , EventEmitter} from '@angular/core';

@Component({
  selector: 'app-toggle-button',
  templateUrl: './toggle-button.component.html',
  styleUrls: ['./toggle-button.component.scss']
})
export class ToggleButtonComponent implements OnInit {

  @Input() buttonstatus: any;
  @Output() onToggleChange = new EventEmitter<boolean>();
  buttonstatustext: string = "No";
  
  
  constructor() { }

  ngOnInit(): void {
    this.onChangebuttonstatustext();
  }

  buttonToggle(event : any) {
    if (event.target.classList.contains('button__toggle')) {
      event.target.classList.toggle('buttonactive');
    }
    this.onToggleChange.emit(!this.buttonstatus);
    this.buttonstatus = !this.buttonstatus;
    this.onChangebuttonstatustext();
  }

  onChangebuttonstatustext() {
    this.buttonstatustext = this.buttonstatus ? "Yes" : "No";
  }

}

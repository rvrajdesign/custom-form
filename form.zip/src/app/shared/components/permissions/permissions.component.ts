import { Component, OnInit , Input , Output , EventEmitter } from '@angular/core';

@Component({
  selector: 'app-permissions',
  templateUrl: './permissions.component.html',
  styleUrls: ['./permissions.component.scss']
})
export class PermissionsComponent implements OnInit {

  @Input() singlepermissionCard : any;
  @Input() permissionIndex : any;
  @Input() accessLen : any;
  @Output() PremissionDataUpdate = new EventEmitter<any>();

  constructor() { }

  ngOnInit(): void {
  }

  onChangeButtonStatus(buttonStatus) {
    this.singlepermissionCard.status = buttonStatus;
    this.singlepermissionCard.index = this.permissionIndex;
    this.PremissionDataUpdate.emit(this.singlepermissionCard); 
  }

}
